BASE_URL = "https://apihub.document360.io/v2"
API_TOKEN = "M1XbCrQnV47mHjZcYnpsUBStnh3QvUqiVv7Jn7oE5VkRiDQmDLbO2eh5LmHqlgsa+zCapZOTjkZyx1Tt6Ym88HmG2+E436HW+jJS28THUUMVb5OQUbps2RRENEybc4K7PtUJz0gOIpqPoBjHlQMenA=="
USER_ID = "b777bb7e-dfa9-4aa8-889a-cbce4e7ef73d"
